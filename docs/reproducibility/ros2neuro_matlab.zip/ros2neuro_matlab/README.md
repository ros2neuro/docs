# ros2neuro_matlab

The `r2n_*` functions: the MATLAB twin of every ros2neuro stage (filters, Welch/FFT/spectrogram, FBCSP, decoders, integrators), to replay offline what the
nodes do online. They use the native functions of MATLAB (Signal Processing Toolbox: `butter`, `filter`, `pwelch`, `hann`, ...).

    addpath('ros2neuro_matlab');
    y = r2n_butterworth(x, 'high', 4, 1, 512);

Header of every file: which plugin it reproduces, what it expects and what it returns. The tests that compare them with a real run are in
https://github.com/ros2neuro/ros2neuro_devel_test (folders `pipeline/`, `integrator/`, `processing/`, `filters/`, ...).
