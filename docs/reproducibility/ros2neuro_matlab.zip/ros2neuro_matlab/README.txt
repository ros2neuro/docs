ROS2neuro in MATLAB
===================

r2n/                 one function per stage of the chain (CAR, DC, Laplacian, windows, Butterworth, Welch, Gaussian, integrator, ...).
                     Copy the ones you need. Float32 like ROS 2, no toolbox.
check_functions.m    checks every function: the filters against the output of the ROS 2 nodes (reference/, the first 512 samples
                     of the CSV of the ros2neuro_filters_* packages), the others on cases whose answer is known.
                     check_functions('/path/to/src') uses the full CSV of a workspace instead.
check_evaluation.m   the whole chain (Laplacian, Welch, Gaussian, integrator, outcome of every trial) on a recorded evaluation,
                     compared with what ROS 2 published. Unzip ros2neuro_matlab_example.zip here (it adds example/) and run it
                     with no arguments. Needs BIOSIG for sload (reading the GDF).

Start:   check_functions        then, with the example:   check_evaluation
Docs:    https://ros2neuro.github.io/docs/reproducibility/matlab/
