ROS2neuro in MATLAB
===================

One function per stage of the chain (CAR, DC, Laplacian, windows, Butterworth, Welch, FFT, spectrogram, FBCSP, Gaussian, LDA, QDA,
SVM, exponential and buffer integrators, ...). Copy the ones you need. Float32 like ROS 2. The filters use the native functions
of MATLAB (Signal Processing Toolbox: butter, filter, hann, ...).

Docs:    https://ros2neuro.github.io/docs/reproducibility/matlab/
Tests:   https://github.com/ros2neuro/ros2neuro_devel_test
