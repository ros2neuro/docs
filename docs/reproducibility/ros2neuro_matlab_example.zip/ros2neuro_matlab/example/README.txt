Example for check_evaluation.m
==============================

One evaluation of ros2neuro_devel_test/launch/gaussian_4class (4 classes, 8 trials), recorded with
    ros2 launch ros2neuro_devel_test gaussian_4class_matlab.launch.xml

evaluation.gdf       the raw EEG and the events of the protocol, written by the recorder
run/                 a CSV of every topic of the run (raw, filtered, psd, prediction, integrated, flow, events), meta.txt
gaussian_4class/     the yaml files and the model the launcher used (check_evaluation reads every parameter from them)

Unzip it next to ros2neuro_matlab.zip (both extract into ros2neuro_matlab/), then in MATLAB:  check_evaluation
