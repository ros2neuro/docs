ROS2neuro in Python
===================

The same functions as the MATLAB ones (CAR, DC, Laplacian, windows, Butterworth, Welch, FFT, spectrogram, FBCSP, Gaussian, LDA, QDA,
SVM, integrators, ...) with numpy and scipy, plus the loaders of the .r2nd models, of the scikit-learn models (skops) and of the
deep-learning models (braindecode / PyTorch). Put the folder on sys.path and import the function you need.

Docs:    https://ros2neuro.github.io/docs/reproducibility/python/
Tests:   https://github.com/ros2neuro/ros2neuro_devel_test
